ask each participant to enter their participant code as their number such as p1, p2 etc
c1 = use dominant hand for the test s0 to s5 times ( s0 is practice session)
c2 = use non dominant hand

for each condition c1 and c2 do the test s0 to s5 times

place all zip files you get from https://webfitt.ngrok.io/ under data folder
